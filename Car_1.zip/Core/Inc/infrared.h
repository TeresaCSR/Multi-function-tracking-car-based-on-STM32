#ifndef INC_INFRARED_H_
#define INC_INFRARED_H_

void Track();
void Left_Gentel();
void Right_Gentel();
void Left_RightAngle();
void Right_RightAngle();
void Left_Hairpin();
void Right_Hairpin();

#endif
