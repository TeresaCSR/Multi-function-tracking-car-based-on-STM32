#ifndef INC_MOTOR_H_
#define INC_MOTOR_H_

extern uint8_t receive[2];
void Stop();
void GoHead();
void GoBack();
void TurnLeft();
void TurnRight();


#endif /* INC_MOTOR_H_ */
