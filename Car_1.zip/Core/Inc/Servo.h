#ifndef INC_SERVO_H_
#define INC_SERVO_H_

void ServoSetAngle(int type);

#endif
