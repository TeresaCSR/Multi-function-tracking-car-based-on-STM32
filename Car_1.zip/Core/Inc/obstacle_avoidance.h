#ifndef INC_OBSTACLE_AVOIDANCE_H_
#define INC_OBSTACLE_AVOIDANCE_H_

void GoHead_1();
void GoHead_2();
void GoHead_3();
void GoBack_1();
void GoBack_2();
void GoBack_3();
void TurnLeft_1();
void TurnLeft_2();
void TurnLeft_3();
void TurnRight_1();
void TurnRight_2();
void TurnRight_3();
void Quick_Turn_Right();
void Quick_Turn_Left();
void Auto_Obstacle_Avoidance_Slow();
void Auto_Obstacle_Avoidance_Fast();
void obstacle_front();
void obstacle_front_left();
void obstacle_front_right();
void obstacle_front_left_right();

#endif /* INC_OBSTACLE_AVOIDANCE_H_ */
